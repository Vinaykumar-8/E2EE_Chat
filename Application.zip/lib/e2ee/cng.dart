// lib/cng.dart
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

/// CNG analysis result status
enum AnalysisStatus { CLEAN, NEUTRALIZED, RISK_DETECTED }

/// Returnable structure converted to simple Map for compute()
class CngResult {
  final AnalysisStatus status;
  final Uint8List?
      neutralizedBytes; // if neutralized, contains safe version (commented/triple-quoted)
  final String displayText; // safe short textual preview for UI
  final String metadata; // why it was flagged

  CngResult({
    required this.status,
    this.neutralizedBytes,
    required this.displayText,
    required this.metadata,
  });

  Map<String, dynamic> toMap() {
    return {
      'status': status.toString().split('.').last,
      'neutralizedBase64':
          neutralizedBytes != null ? base64Url.encode(neutralizedBytes!) : null,
      'displayText': displayText,
      'metadata': metadata,
    };
  }
}

/// Top-level function for compute() (must be top-level)
/// args: [filename (String), fileBytes (Uint8List)]
Future<Map<String, dynamic>> safeFileAnalysis(List<dynamic> args) async {
  final String filename = args[0] as String;
  final Uint8List fileBytes = args[1] as Uint8List;

  String ext = '';
  if (filename.contains('.')) {
    ext = filename.split('.').last.toLowerCase();
  }

  bool startsWith(Uint8List b, List<int> header) {
    if (b.length < header.length) return false;
    for (int i = 0; i < header.length; i++) if (b[i] != header[i]) return false;
    return true;
  }

  // Category sets
  final sourceExts = {
    'py',
    'java',
    'c',
    'cpp',
    'cc',
    'h',
    'hpp',
    'js',
    'ts',
    'html',
    'htm',
    'cs',
    'go',
    'rb',
    'php'
  };
  final docExts = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'rtf'};
  final exeExts = {'exe', 'dll', 'bat', 'sh', 'apk', 'bin', 'elf'};

  // 1) SOURCE FILES
  if (sourceExts.contains(ext)) {
    String text;
    try {
      text = utf8.decode(fileBytes);
    } catch (e) {
      return CngResult(
        status: AnalysisStatus.RISK_DETECTED,
        neutralizedBytes: null,
        displayText: 'Blocked: source file is not valid UTF-8.',
        metadata: 'UTF-8 decode error: $e',
      ).toMap();
    }

    final cLike = {
      'c',
      'cpp',
      'cc',
      'h',
      'hpp',
      'java',
      'js',
      'ts',
      'cs',
      'go'
    };
    String neutralized;
    if (cLike.contains(ext)) {
      neutralized =
          '/* [NEUTRALIZED: START] */\n$text\n/* [NEUTRALIZED: END] */';
    } else {
      neutralized = '"""[NEUTRALIZED START]\n$text\n[NEUTRALIZED END]"""';
    }

    // Heuristics
    final patterns = <String>[
      r'\beval\s*\(',
      r'\bexec\s*\(',
      r'\bos\.system\b',
      r'\bsubprocess\b',
      r'\bRuntime\.exec\b',
      r'\bProcessBuilder\b',
      r'\bbase64_decode\b',
      r'0x[0-9a-fA-F]{10,}' // long hex blobs
    ];

    final found = <String>[];
    for (final p in patterns) {
      try {
        final r = RegExp(p);
        if (r.hasMatch(text)) found.add(p);
      } catch (_) {}
    }

    if (found.isNotEmpty) {
      final meta = 'Suspicious patterns: ${found.join(', ')}';
      return CngResult(
        status: AnalysisStatus.NEUTRALIZED,
        neutralizedBytes: Uint8List.fromList(utf8.encode(neutralized)),
        displayText: neutralized.length > 1000
            ? neutralized.substring(0, 1000) + '...'
            : neutralized,
        metadata: meta,
      ).toMap();
    }

    return CngResult(
      status: AnalysisStatus.CLEAN,
      neutralizedBytes: null,
      displayText: text.length > 1000 ? text.substring(0, 1000) + '...' : text,
      metadata: 'No suspicious patterns found.',
    ).toMap();
  }

  // 2) DOCUMENTS
  if (docExts.contains(ext)) {
    // PDF: check header and keywords
    if (ext == 'pdf' || startsWith(fileBytes, [0x25, 0x50, 0x44, 0x46, 0x2D])) {
      final asText = const Latin1Codec(allowInvalid: true).decode(fileBytes);
      final suspicious = <String>[];
      if (asText.contains('/JavaScript') || asText.contains('/JS'))
        suspicious.add('PDF JavaScript');
      if (asText.contains('/OpenAction'))
        suspicious.add('OpenAction/AutoLaunch');
      if (suspicious.isNotEmpty) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: PDF contains script markers.',
          metadata: 'Found: ${suspicious.join(', ')}',
        ).toMap();
      } else {
        return CngResult(
          status: AnalysisStatus.CLEAN,
          neutralizedBytes: null,
          displayText: '[PDF scanned: no script markers found]',
          metadata: 'PDF appears clean.',
        ).toMap();
      }
    }

    // Office OOXML: zip check for vbaProject
    if (startsWith(fileBytes, [0x50, 0x4B])) {
      final asText = const Latin1Codec(allowInvalid: true).decode(fileBytes);
      if (asText.contains('vbaProject') || asText.contains('VBA/')) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: Office document contains macros.',
          metadata: 'vbaProject found in archive',
        ).toMap();
      } else {
        return CngResult(
          status: AnalysisStatus.CLEAN,
          neutralizedBytes: null,
          displayText: '[Office document: no macros found]',
          metadata: 'OOXML archive scanned.',
        ).toMap();
      }
    }

    // Generic doc fallback
    return CngResult(
      status: AnalysisStatus.CLEAN,
      neutralizedBytes: null,
      displayText: '[Document scanned: no macros found by heuristics]',
      metadata: 'Generic document fallback.',
    ).toMap();
  }

  // 3) EXECUTABLES & SCRIPTS
  if (exeExts.contains(ext)) {
    // PE header
    if (startsWith(fileBytes, [0x4D, 0x5A])) {
      final asText = const Latin1Codec(allowInvalid: true).decode(fileBytes);
      final suspicious = <String>[];
      if (asText.contains('UPX!')) suspicious.add('UPX packer');
      if (suspicious.isNotEmpty) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: Packed/obfuscated executable detected.',
          metadata: 'Found: ${suspicious.join(', ')}',
        ).toMap();
      }
      return CngResult(
        status: AnalysisStatus.RISK_DETECTED,
        neutralizedBytes: null,
        displayText: 'Blocked: Executable files are not allowed.',
        metadata: 'PE header detected; policy blocks executables.',
      ).toMap();
    }

    // Shell/BAT text scripts - neutralize by commenting
    if (ext == 'sh' || ext == 'bat') {
      String text;
      try {
        text = utf8.decode(fileBytes);
      } catch (e) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: script appears binary/unreadable.',
          metadata: 'Script decode error: $e',
        ).toMap();
      }
      final inj = RegExp(
          r'\b(rm\s+-rf|curl\s+http|wget\s+http|chmod\s+777|:(){:|:};)\b',
          caseSensitive: false);
      if (inj.hasMatch(text)) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: destructive or network operations found.',
          metadata: 'Matched destructive patterns.',
        ).toMap();
      }
      // Neutralize
      if (ext == 'sh') {
        final commented =
            text.split('\n').map((l) => '# NEUTRALIZED: $l').join('\n');
        return CngResult(
          status: AnalysisStatus.NEUTRALIZED,
          neutralizedBytes: Uint8List.fromList(utf8.encode(commented)),
          displayText: commented.length > 1000
              ? commented.substring(0, 1000) + '...'
              : commented,
          metadata: 'Script neutralized by commenting.',
        ).toMap();
      } else {
        final commented =
            text.split('\n').map((l) => 'REM NEUTRALIZED: $l').join('\r\n');
        return CngResult(
          status: AnalysisStatus.NEUTRALIZED,
          neutralizedBytes: Uint8List.fromList(utf8.encode(commented)),
          displayText: commented.length > 1000
              ? commented.substring(0, 1000) + '...'
              : commented,
          metadata: 'Batch neutralized by REM prefix.',
        ).toMap();
      }
    }

    // APK detection via zip header + AndroidManifest
    if (startsWith(fileBytes, [0x50, 0x4B])) {
      final asText = const Latin1Codec(allowInvalid: true).decode(fileBytes);
      if (asText.contains('AndroidManifest.xml')) {
        return CngResult(
          status: AnalysisStatus.RISK_DETECTED,
          neutralizedBytes: null,
          displayText: 'Blocked: APK package detected.',
          metadata: 'APK found in ZIP.',
        ).toMap();
      }
    }

    return CngResult(
      status: AnalysisStatus.RISK_DETECTED,
      neutralizedBytes: null,
      displayText: 'Blocked: Unknown binary; blocked by policy.',
      metadata: 'Generic executable/binary blocked.',
    ).toMap();
  }

  // Default: try to decode as text and show
  try {
    final text = utf8.decode(fileBytes);
    return CngResult(
      status: AnalysisStatus.CLEAN,
      neutralizedBytes: null,
      displayText: text.length > 1000 ? text.substring(0, 1000) + '...' : text,
      metadata: 'Unknown extension but text decoded.',
    ).toMap();
  } catch (_) {
    return CngResult(
      status: AnalysisStatus.CLEAN,
      neutralizedBytes: fileBytes,
      displayText: '[Binary file passed CNG: ${fileBytes.length} bytes]',
      metadata: 'Binary passed without modification.',
    ).toMap();
  }
}
