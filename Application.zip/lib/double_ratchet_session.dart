import 'dart:convert';
import 'dart:typed_data';

// Key length constant (32 bytes = 256 bits)
const int KEY_LENGTH = 32;

// --- E2EE Data Structures ---

class MessageHeader {
  // FIX: Removed 'final' to allow modification after instantiation
  Uint8List? ephemeralKey; // Our new DH public key (E_self)
  final int pn; // Previous message count (N_s from the last DH Ratchet)
  final int n; // Current message count (N_s in the current chain)
  final Uint8List iv; // Initialization Vector for AES-GCM
  final Uint8List ciphertext;

  MessageHeader({
    this.ephemeralKey, // Made optional and non-required here
    required this.pn,
    required this.n,
    required this.iv,
    required this.ciphertext,
  });
}

/// A simplified class to hold the key material (bytes) for DH and Message Keys.
class CryptoKeyMaterial {
  final Uint8List keyBytes;
  CryptoKeyMaterial(this.keyBytes);
}

/// Represents the private key pair we hold (E_self)
class DhKeyPair {
  final Uint8List privateKey;
  final Uint8List publicKey;
  DhKeyPair(this.privateKey, this.publicKey);
}

// --- Double Ratchet State Class ---

class DoubleRatchetSession {
  // --- Core State ---
  CryptoKeyMaterial rootKey;
  CryptoKeyMaterial sendingChainKey;
  CryptoKeyMaterial receivingChainKey;
  DhKeyPair dhPair; // Our private/public key pair
  Uint8List remotePubKey; // Their last sent public key (E_remote)

  // --- Counters and History ---
  int n_s = 0; // Number of messages sent in current sending chain
  int n_r = 0; // Number of messages received in current receiving chain
  int pn = 0; // Previous N_s (before last DH ratchet)
  Map<String, CryptoKeyMaterial> skippedKeys = {}; // For out-of-order messages

  DoubleRatchetSession({
    required this.rootKey,
    required this.sendingChainKey,
    required this.receivingChainKey,
    required this.dhPair,
    required this.remotePubKey,
  });

  // --- Cryptographic Placeholders (Replace with actual 'cryptography' package calls) ---

  // Placeholder for X25519 Key Generation
  static DhKeyPair generateDhKeyPairPlaceholder() {
    // In production: return X25519.newKeypair().privateKey/publicKey
    final privateKey =
        Uint8List.fromList(List.generate(KEY_LENGTH, (i) => i + 1));
    final publicKey =
        Uint8List.fromList(List.generate(KEY_LENGTH, (i) => KEY_LENGTH - i));
    return DhKeyPair(privateKey, publicKey);
  }

  // Placeholder for ECDH Shared Secret Calculation
  Uint8List dhSharedSecretPlaceholder(
      Uint8List privateKey, Uint8List publicKey) {
    // In production: return X25519.sharedSecret(privateKey, publicKey)
    // For simulation, just XOR the two keys (NOT CRYPTOGRAPHICALLY SECURE!)
    return Uint8List.fromList(
        List.generate(KEY_LENGTH, (i) => privateKey[i] ^ publicKey[i]));
  }

  // Placeholder for HKDF (Hash-Based Key Derivation Function)
  List<CryptoKeyMaterial> hkdfDeriveKeysPlaceholder(
      Uint8List prk, Uint8List salt, String info, int outputCount) {
    // In production: Use Hkdf(Hmac.sha256(), secret: prk).deriveKeys()
    // Returns a list of keys, each of length KEY_LENGTH
    return List.generate(outputCount, (i) {
      // Simulate key expansion by adding the index to the PRK
      return CryptoKeyMaterial(
          Uint8List.fromList(prk.map((byte) => (byte + i) % 256).toList()));
    });
  }

  // Placeholder for AES-GCM Encryption
  MessageHeader encryptPlaceholder(
      CryptoKeyMaterial messageKey, String plaintext) {
    // In production: Use AesGcm(SecretKey(messageKey)).encrypt()
    final iv = Uint8List.fromList(List.generate(12, (i) => 0xFF - i));
    final plaintextBytes = utf8.encode(plaintext);

    // Simulate encryption by XORing with a static prefix for a simple, non-secure demo
    final ciphertext =
        Uint8List.fromList(plaintextBytes.map((b) => b ^ 0xAA).toList());

    // The ephemeralKey is set to null initially, and updated below if necessary
    return MessageHeader(
      ephemeralKey: null,
      pn: pn,
      n: n_s,
      iv: iv,
      ciphertext: ciphertext,
    );
  }

  // Placeholder for AES-GCM Decryption
  String decryptPlaceholder(
      CryptoKeyMaterial messageKey, Uint8List ciphertext, Uint8List iv) {
    // In production: Use AesGcm(SecretKey(messageKey)).decrypt()

    // Simulate decryption by XORing with the same static prefix
    final decryptedBytes = ciphertext.map((b) => b ^ 0xAA).toList();
    return utf8.decode(decryptedBytes);
  }

  // --- Key Derivation Functions ---

  /// **DH Ratchet Step**: Derives new RK and CK from the shared secret.
  /// RK' and CK' are derived from the previous RK and the new DH_out.
  void _kdfRk(Uint8List dhOut) {
    // 1. HKDF-Extract(RK_old, DH_out) -> PRK
    // 2. HKDF-Expand(PRK, info) -> RK_new || CK_new (64 bytes total)

    // Placeholder: uses dhOut as a pseudo-PRK (Not a real HKDF extract)
    final newKeys = hkdfDeriveKeysPlaceholder(
        dhOut, Uint8List(KEY_LENGTH), "DoubleRatchetRK", 2);

    rootKey = newKeys[0]; // RK'
    receivingChainKey = newKeys[1]; // CK_new becomes the receiving chain key

    // Update counters
    pn = n_s;
    n_r = 0;
  }

  /// **Symmetric Ratchet Step**: Derives the next CK and the MK.
  /// CK' and MK are derived from the current CK.
  (CryptoKeyMaterial, CryptoKeyMaterial) _kdfCk(CryptoKeyMaterial chainKey) {
    // HKDF-Extract(CK_old, ZEROs) -> PRK (CK_old itself acts as PRK for next step)
    // HKDF-Expand(CK_old, info) -> CK_next || MK (64 bytes total)

    final newKeys = hkdfDeriveKeysPlaceholder(
        chainKey.keyBytes, Uint8List(KEY_LENGTH), "DoubleRatchetCK", 2);

    final nextCk = newKeys[0];
    final messageKey = newKeys[1];

    return (nextCk, messageKey);
  }

  // --- DH Ratchet Logic ---

  /// Triggers a DH ratchet step upon receiving a message with a new public key.
  void _dhRatchetStep(Uint8List receivedPubKey) {
    // 1. Compute DH_out (Shared Secret)
    final dhOut = dhSharedSecretPlaceholder(dhPair.privateKey, receivedPubKey);

    // 2. Derive new RK' and RCK'
    _kdfRk(dhOut);

    // 3. Store the received public key as the new E_remote
    remotePubKey = receivedPubKey;

    // 4. Generate a new DH key pair for sending (E_self_new)
    dhPair = generateDhKeyPairPlaceholder();

    // 5. Derive new SCK' from the new RK'
    // NOTE: For simplicity here, we assume the RCK' becomes the initial SCK' of the new chain:
    sendingChainKey = receivingChainKey;

    n_s = 0; // Reset sending counter
    print("--- DH Ratchet Step Completed: Keys Updated ---");
  }

  // --- Public Message Methods ---

  /// Encrypts a message, advances the sending symmetric chain, and optionally includes a new DH key.
  MessageHeader sendMessage(String messageText, {bool includeDhKey = false}) {
    // 1. Symmetric Ratchet: Derive Message Key (MK) and Next Chain Key (SCK_new)
    final (nextCk, messageKey) = _kdfCk(sendingChainKey);

    // 2. Update state
    sendingChainKey = nextCk;

    // 3. Encrypt the message (using the one-time MK)
    final messageHeader = encryptPlaceholder(messageKey, messageText);

    // 4. Update the ephemeral key in the header if requested
    if (includeDhKey) {
      // FIX APPLIED: ephemeralKey is no longer final, so this works.
      messageHeader.ephemeralKey = dhPair.publicKey;
    }

    // 5. Increment sending counter (after encryption to get the correct counter in the header)
    n_s++;

    print(
        "Sent Message (N_s: $n_s, PN: $pn, Ephemeral Included: ${includeDhKey})");
    return messageHeader;
  }

  /// Decrypts a message, potentially performs a DH ratchet step, and advances the receiving symmetric chain.
  String receiveMessage(MessageHeader header) {
    // 1. Check for DH Ratchet Trigger
    if (header.ephemeralKey != null) {
      _dhRatchetStep(header.ephemeralKey!);
    }

    // 2. Check for Skipped Keys (Out-of-order message)
    // Implementation omitted for brevity but required in a real-world chat.

    // 3. Symmetric Ratchet: Advance the receiving chain to the required index (n)
    CryptoKeyMaterial messageKey = receivingChainKey;
    while (n_r < header.n) {
      final (nextCk, currentMessageKey) = _kdfCk(receivingChainKey);
      receivingChainKey = nextCk;
      n_r++;

      if (n_r == header.n) {
        messageKey = currentMessageKey;
        break; // Found the key for the current message
      }
      // If n_r < header.n, the currentMessageKey should be stored in skippedKeys.
    }

    // 4. Decrypt the message
    if (n_r != header.n) {
      throw Exception(
          "Failed to derive key for message index ${header.n}. Message may be lost or out of order.");
    }

    // NOTE: The IV is part of the MessageHeader DTO
    final plaintext =
        decryptPlaceholder(messageKey, header.ciphertext, header.iv);

    print(
        "Received Message (N_r: $n_r, Ephemeral Present: ${header.ephemeralKey != null})");

    return plaintext;
  }
}
