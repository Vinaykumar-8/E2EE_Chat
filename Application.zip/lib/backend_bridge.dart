// lib/backend_bridge.dart
// Common backend interface for both Firebase and Local (FlutLab) backends.

import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

// -------------------- Abstract Backend Interface --------------------
abstract class BackendBridge {
  Future<void> publishPublicKeys(
      String userId, String identityB64, String ephemeralB64);
  Future<Map<String, String>?> fetchPublicKeys(String userId);
  Future<void> pushMessage(String recipientId, Map<String, dynamic> message);
  Future<List<Map<String, dynamic>>> pollMessages(String recipientId);
  Future<void> clearMailbox(String recipientId);
}

// -------------------- Local (Flutlab) Backend --------------------
class LocalBackendBridge implements BackendBridge {
  static final Map<String, Map<String, String>> _publicKeys = {};
  static final Map<String, List<Map<String, dynamic>>> _mailboxes = {};

  @override
  Future<void> publishPublicKeys(
      String userId, String identityB64, String ephemeralB64) async {
    _publicKeys[userId] = {'identity': identityB64, 'ephemeral': ephemeralB64};
  }

  @override
  Future<Map<String, String>?> fetchPublicKeys(String userId) async {
    return _publicKeys[userId];
  }

  @override
  Future<void> pushMessage(
      String recipientId, Map<String, dynamic> message) async {
    _mailboxes.putIfAbsent(recipientId, () => []);
    _mailboxes[recipientId]!.add(message);
  }

  @override
  Future<List<Map<String, dynamic>>> pollMessages(String recipientId) async {
    return List<Map<String, dynamic>>.from(_mailboxes[recipientId] ?? []);
  }

  @override
  Future<void> clearMailbox(String recipientId) async {
    _mailboxes[recipientId] = [];
  }
}

// -------------------- Firebase Backend --------------------
class FirebaseBackendBridge implements BackendBridge {
  static bool _initialized = false;

  static Future<void> initFirebase() async {
    if (!_initialized) {
      await Firebase.initializeApp();
      _initialized = true;
    }
  }

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Future<void> publishPublicKeys(
      String userId, String identityB64, String ephemeralB64) async {
    await initFirebase();
    await _firestore.collection('publicKeys').doc(userId).set({
      'identity': identityB64,
      'ephemeral': ephemeralB64,
      'updatedAt': DateTime.now().millisecondsSinceEpoch,
    });
  }

  @override
  Future<Map<String, String>?> fetchPublicKeys(String userId) async {
    await initFirebase();
    final doc = await _firestore.collection('publicKeys').doc(userId).get();
    if (!doc.exists) return null;
    final data = doc.data();
    return {
      'identity': data?['identity'] ?? '',
      'ephemeral': data?['ephemeral'] ?? '',
    };
  }

  @override
  Future<void> pushMessage(
      String recipientId, Map<String, dynamic> message) async {
    await initFirebase();
    await _firestore
        .collection('mailboxes')
        .doc(recipientId)
        .collection('inbox')
        .add(message);
  }

  @override
  Future<List<Map<String, dynamic>>> pollMessages(String recipientId) async {
    await initFirebase();
    final query = await _firestore
        .collection('mailboxes')
        .doc(recipientId)
        .collection('inbox')
        .get();
    return query.docs.map((doc) => doc.data()).toList();
  }

  @override
  Future<void> clearMailbox(String recipientId) async {
    await initFirebase();
    final batch = _firestore.batch();
    final inboxRef =
        _firestore.collection('mailboxes').doc(recipientId).collection('inbox');
    final query = await inboxRef.get();
    for (final doc in query.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
}
