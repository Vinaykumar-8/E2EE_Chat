import 'package:flutter/material.dart';
import 'services/security_service.dart';
import 'dart:convert';
import 'dart:typed_data';

final SecurityService _securityService = SecurityService();
const String USER_PASSWORD = "MySecureLoginPassword123";

void main() {
  runApp(const E2EApp());
}

class E2EApp extends StatelessWidget {
  const E2EApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dual-Layer Security App',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        appBarTheme: const AppBarTheme(elevation: 0, color: Colors.deepPurple),
      ),
      home: const HomeLauncher(),
    );
  }
}

class HomeLauncher extends StatefulWidget {
  const HomeLauncher({super.key});

  @override
  State<HomeLauncher> createState() => _HomeLauncherState();
}

class _HomeLauncherState extends State<HomeLauncher> {
  late Future<void> _initializationFuture;

  @override
  void initState() {
    super.initState();

    _initializationFuture = _securityService.initializeSecurity(USER_PASSWORD);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _initializationFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                  child: Text("FATAL ERROR: Security Initialization Failed.")),
            );
          }
          return const ChatScreen();
        } else {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 20),
                  Text("Deriving Master Key... (Layer 1: SKP in progress)"),
                ],
              ),
            ),
          );
        }
      },
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<String> _eventHistory = [
    "✅ Security Initialized (Layer 1: SKP Ready)"
  ];

  void _addEvent(String event) {
    setState(() {
      _eventHistory.insert(0, event);
    });
  }

  void _handleSend() async {
    final message = _controller.text;
    if (message.isNotEmpty) {
      _addEvent("🛫 Sending: Starting Layer 1 E2EE encryption...");
      final success = await _securityService.sendMessage(message);

      if (success) {
        _addEvent("✔️ Message sent. N(S) updated (Double Ratchet).");
      }
      _controller.clear();
    }
  }

  void _handleReceiveAttachment(Uint8List encryptedAttachmentBytes) async {
    _addEvent(
        "⬇️ Received encrypted attachment. Starting Layer 1 decryption...");

    const filename = 'malicious_script.py';
    const fileType = 'script';

    final safeContent = await _securityService.processAttachment(
        filename, encryptedAttachmentBytes, fileType);

    if (safeContent.contains("BLOCKED") || safeContent.contains("ERROR")) {
      _addEvent("❌ Layer 1/2 Check FAILED: $safeContent");
    } else {
      _addEvent("🛡️ Layer 2 (CNG) Success! Content neutralized/safe.");
      _addEvent("   Safe Content Snapshot: ${safeContent.substring(0, 50)}...");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dual-Layer Secure Chat')),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              color: Colors.grey.shade50,
              padding: const EdgeInsets.all(10.0),
              child: ListView.builder(
                reverse: true,
                itemCount: _eventHistory.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: Text(
                      _eventHistory[index],
                      style: TextStyle(
                        fontSize: 13,
                        color: _eventHistory[index].startsWith("❌") ||
                                _eventHistory[index].contains("BLOCKED")
                            ? Colors.red
                            : Colors.black87,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                        labelText: 'Enter secure message...'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _handleSend,
                  tooltip: 'Layer 1: Send Message',
                ),
                IconButton(
                  icon: const Icon(Icons.download),
                  onPressed: () {
                    const simulatedEncryptedAttachmentString =
                        "EncryptedPayload: 0xDEADBEEF...";
                    final encryptedBytes = Uint8List.fromList(
                        utf8.encode(simulatedEncryptedAttachmentString));

                    _handleReceiveAttachment(encryptedBytes);
                  },
                  tooltip: 'Layers 1 & 2: Receive & Check Attachment',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
