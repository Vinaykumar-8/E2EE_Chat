import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'AIzaSyBTlv9wChrTl7qV1_l0zTb6A2XcSLnIuhg',
    appId: '1:263825783976:android:8f2192a50cd3aa975e969d',
    messagingSenderId: '263825783976',
    projectId: 'e2ee-13f96',
    storageBucket: 'e2ee-13f96.firebasestorage.app',
    authDomain: null, // optional for web, can leave null for Android
    measurementId: null, // optional, only if using analytics
  );
}
