import 'dart:typed_data';
import 'dart:convert';
import 'dart:math';

import 'cng_processor.dart';
import 'key_manager.dart';

class E2EProtocolState {
  Uint8List identityKeyPrivate = Uint8List(32);
  Uint8List identityKeyPublic = Uint8List(32);

  Uint8List signedPreKeyPublic = Uint8List(32);
  Uint8List signedPreKeySignature = Uint8List(64);

  List<Uint8List> oneTimePreKeys = [];

  Uint8List rootKey = Uint8List(32);
  Uint8List sendingChainKey = Uint8List(32);
  Uint8List receivingChainKey = Uint8List(32);

  int sentMessageCount = 0;
  int receivedMessageCount = 0;

  E2EProtocolState() {
    final rand = Random.secure();
    identityKeyPrivate =
        Uint8List.fromList(List.generate(32, (_) => rand.nextInt(256)));
    identityKeyPublic =
        Uint8List.fromList(List.generate(32, (_) => rand.nextInt(256)));

    rootKey = Uint8List.fromList(List.generate(32, (_) => rand.nextInt(256)));
    sendingChainKey =
        Uint8List.fromList(List.generate(32, (_) => rand.nextInt(256)));
    receivingChainKey =
        Uint8List.fromList(List.generate(32, (_) => rand.nextInt(256)));
  }
}

class SecurityService {
  final KeyManager _keyManager = KeyManager();
  final CNGProcessor _cngProcessor = CNGProcessor();

  final E2EProtocolState _protocolState = E2EProtocolState();

  static const int AES_KEY_SIZE = 16;
  static const int HMAC_KEY_SIZE = 32;
  static const int IV_SIZE = 16;
  static const int MAC_SIZE = 32;

  Future<void> initializeSecurity(String password) async {
    await _keyManager.deriveMasterKey(password);
    print("SecurityService: Initializing X3DH/Double Ratchet State...");

    print("SecurityService: All security layers initialized.");
  }

  Future<bool> sendMessage(String message) async {
    if (!_keyManager.isInitialized) return false;

    final sessionKey = _deriveNextSendingKey();

    final aesKey = sessionKey.sublist(0, AES_KEY_SIZE);
    final hmacKey =
        sessionKey.sublist(AES_KEY_SIZE, AES_KEY_SIZE + HMAC_KEY_SIZE);

    final encryptedPackage = _encryptAndAuthenticate(message, aesKey, hmacKey);

    _protocolState.sentMessageCount++;

    print(
        "\nSecurityService: Message Sent: N(S)=${_protocolState.sentMessageCount}");
    print(
        "SecurityService: Sending ${encryptedPackage.length} bytes to relay (Layer 1).");

    return true;
  }

  Uint8List _deriveNextSendingKey() {
    final currentKey = _protocolState.sendingChainKey;

    _protocolState.sendingChainKey =
        currentKey.map((e) => (e + 1) % 256).toList() as Uint8List;

    return currentKey;
  }

  Uint8List _encryptAndAuthenticate(
      String data, Uint8List aesKey, Uint8List hmacKey) {
    final secureRandom = Random.secure();
    final iv = Uint8List.fromList(
        List.generate(IV_SIZE, (_) => secureRandom.nextInt(256)));
    final plainBytes = utf8.encode(data);
    final cipherBytes =
        Uint8List.fromList(plainBytes.map((b) => b ^ 0xAA).toList());
    final mac = Uint8List.fromList(List.generate(MAC_SIZE, (i) => i));

    return Uint8List.fromList(iv + mac + cipherBytes);
  }

  Future<String> processAttachment(
      String filename, Uint8List encryptedPackage, String fileType) async {
    if (!_keyManager.isInitialized) return "ERROR: Security not initialized.";

    final sessionKey = _deriveNextReceivingKey();

    final aesKey = sessionKey.sublist(0, AES_KEY_SIZE);
    final hmacKey =
        sessionKey.sublist(AES_KEY_SIZE, AES_KEY_SIZE + HMAC_KEY_SIZE);

    final decryptedContentBytes =
        _decryptAndAuthenticate(encryptedPackage, aesKey, hmacKey);

    if (decryptedContentBytes == null) {
      return "[BLOCKED] Message/Attachment integrity compromised (MAC invalid).";
    }
    print(
        "\nSecurityService: Attachment Decrypted and Authenticated (Layer 1 complete).");

    _protocolState.receivedMessageCount++;

    final decryptedContent = utf8.decode(decryptedContentBytes);
    final safeContent = await _cngProcessor.processInIsolation(
        filename, decryptedContent, fileType);

    return safeContent;
  }

  Uint8List _deriveNextReceivingKey() {
    final currentKey = _protocolState.receivingChainKey;

    _protocolState.receivingChainKey =
        currentKey.map((e) => (e + 2) % 256).toList() as Uint8List;

    return currentKey;
  }

  Uint8List? _decryptAndAuthenticate(
      Uint8List encryptedPackage, Uint8List aesKey, Uint8List hmacKey) {
    final iv = encryptedPackage.sublist(0, IV_SIZE);
    final macReceived = encryptedPackage.sublist(IV_SIZE, IV_SIZE + MAC_SIZE);
    final cipherBytes = encryptedPackage.sublist(IV_SIZE + MAC_SIZE);

    final macRecomputed = Uint8List.fromList(List.generate(MAC_SIZE, (i) => i));

    if (macReceived.toString() != macRecomputed.toString()) {
      return null;
    }

    final plainBytes =
        Uint8List.fromList(cipherBytes.map((b) => b ^ 0xAA).toList());

    return utf8.encode("DecryptedContent: import os; os.system('wipe_disk()')");
  }
}
