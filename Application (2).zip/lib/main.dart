import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:typed_data';

// --- 🔒 SecurityService Implementation (Refinement: Define the service) ---

/// A service to handle cryptographic operations (Layer 1) and
/// content analysis/neutralization (Layer 2).
class SecurityService {
  // Layer 1 components
  bool _isInitialized = false;
  String _masterKeyDerived = '';

  // Layer 1 - Double Ratchet simulation (Simplified for demonstration)
  int _sendChainKeyCounter = 0;
  int _receiveChainKeyCounter = 0;

  // Layer 2 components (Content Neutralization/Guardian)
  final List<String> _blockedFileSignatures = ['script', 'executable', 'dll'];

  /// Initializes Layer 1 security by deriving the Master Key from the password.
  /// (Simulates Scrypt/Argon2 - SKP: Symmetric Key Derivation Protocol)
  Future<void> initializeSecurity(String password) async {
    // Simulate intensive Key Derivation Function (KDF) work
    await Future.delayed(const Duration(seconds: 2));

    // In a real app, this would use KDF (like scrypt or PBKDF2)
    // to derive a strong, salted, and hashed master key.
    _masterKeyDerived = 'MasterKey_Hash(${password.length})';
    _isInitialized = true;
    print('SecurityService: Master Key derived: $_masterKeyDerived');
    print('SecurityService: SKP Initialization Complete.');
  }

  /// Handles Layer 1: E2EE encryption of a text message.
  /// (Simulates the Double Ratchet Algorithm's sending phase)
  Future<bool> sendMessage(String plaintext) async {
    if (!_isInitialized) {
      print('SecurityService: ERROR - Not initialized.');
      return false;
    }
    // Simulate encryption using the current Double Ratchet chain key
    _sendChainKeyCounter++;
    final encryptedMessage =
        'Encrypted(${_sendChainKeyCounter}): ${base64.encode(utf8.encode(plaintext))}';

    // Simulate sending the encrypted message over the network
    await Future.delayed(const Duration(milliseconds: 500));

    print('SecurityService: Encrypted Message sent: $encryptedMessage');
    print(
        'SecurityService: Double Ratchet Send Counter updated to $_sendChainKeyCounter');
    return true;
  }

  /// Handles Layer 1 (Decryption) and Layer 2 (Content Neutralization/Guardian - CNG).
  Future<String> processAttachment(
      String filename, Uint8List encryptedBytes, String fileType) async {
    if (!_isInitialized) {
      return "ERROR: Service Not Initialized";
    }

    // --- Layer 1: Decryption (Simulated) ---
    await Future.delayed(const Duration(milliseconds: 500));
    _receiveChainKeyCounter++;
    final decryptedContent = utf8.decode(encryptedBytes).replaceAll(
        'EncryptedPayload: 0xDEADBEEF...',
        'DecryptedContent: import os; os.system(\"evil\")...');

    print(
        'SecurityService: Layer 1 Decryption complete. Counter: $_receiveChainKeyCounter');

    // --- Layer 2: Content Neutralization/Guardian (CNG) Check ---
    await Future.delayed(const Duration(milliseconds: 750));
    print(
        'SecurityService: Starting Layer 2 (CNG) check on fileType: $fileType');

    // Simulate malicious content detection/neutralization
    if (_blockedFileSignatures.contains(fileType.toLowerCase())) {
      // **Simulated Neutralization:** Block execution and return only a safe log.
      final safeLog =
          "BLOCKED: File Type ($fileType) is not allowed. Content neutralized.";
      print('SecurityService: Layer 2 BLOCK triggered for $fileType.');
      return safeLog;
    } else if (decryptedContent.contains("os.system")) {
      // **Simulated Sandboxing/Removal of Harmful Functions**
      final neutralizedContent = decryptedContent.replaceAllMapped(
          RegExp(r'os\.system\(.+?\)'), (match) => 'os.system("BLOCKED_CMD")');
      print('SecurityService: Layer 2 neutralized malicious code.');
      return neutralizedContent;
    }

    // Default safe path
    return "SAFE_TO_PROCESS: $decryptedContent";
  }
}

// --- 🌐 App UI Code (Original code structure remains) ---

final SecurityService _securityService = SecurityService();
const String USER_PASSWORD = "MySecureLoginPassword123";

void main() {
  runApp(const E2EApp());
}

class E2EApp extends StatelessWidget {
  const E2EApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dual-Layer Security App',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        appBarTheme: const AppBarTheme(elevation: 0, color: Colors.deepPurple),
      ),
      home: const HomeLauncher(),
    );
  }
}

class HomeLauncher extends StatefulWidget {
  const HomeLauncher({super.key});

  @override
  State<HomeLauncher> createState() => _HomeLauncherState();
}

class _HomeLauncherState extends State<HomeLauncher> {
  late Future<void> _initializationFuture;

  @override
  void initState() {
    super.initState();

    // Start security initialization immediately upon widget creation
    _initializationFuture = _securityService.initializeSecurity(USER_PASSWORD);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _initializationFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError) {
            return const Scaffold(
              body: Center(
                  child: Text("FATAL ERROR: Security Initialization Failed.")),
            );
          }
          // Initialization successful, navigate to the main chat screen
          return const ChatScreen();
        } else {
          // Show loading/initialization screen
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 20),
                  Text("Deriving Master Key... (Layer 1: SKP in progress)"),
                ],
              ),
            ),
          );
        }
      },
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<String> _eventHistory = [
    "✅ Security Initialized (Layer 1: SKP Ready)"
  ];

  void _addEvent(String event) {
    setState(() {
      // Add new events to the top of the list
      _eventHistory.insert(0, event);
    });
  }

  void _handleSend() async {
    final message = _controller.text;
    if (message.isNotEmpty) {
      _addEvent("🛫 Sending: Starting Layer 1 E2EE encryption...");

      // Call the service to encrypt and simulate sending
      final success = await _securityService.sendMessage(message);

      if (success) {
        _addEvent("✔️ Message sent. N(S) updated (Double Ratchet).");
      }
      _controller.clear();
    }
  }

  void _handleReceiveAttachment(Uint8List encryptedAttachmentBytes) async {
    _addEvent(
        "⬇️ Received encrypted attachment. Starting Layer 1 decryption...");

    // The simulated attachment details
    const filename = 'malicious_script.py';
    const fileType = 'script'; // This will trigger the Layer 2 BLOCK logic

    // Call the service to decrypt (Layer 1) and check/neutralize (Layer 2)
    final safeContent = await _securityService.processAttachment(
        filename, encryptedAttachmentBytes, fileType);

    // Update the UI based on the Layer 1/2 outcome
    if (safeContent.contains("BLOCKED") || safeContent.contains("ERROR")) {
      _addEvent("❌ Layer 1/2 Check FAILED: $safeContent");
    } else {
      _addEvent("🛡️ Layer 2 (CNG) Success! Content neutralized/safe.");
      _addEvent("   Safe Content Snapshot: ${safeContent.substring(0, 50)}...");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dual-Layer Secure Chat')),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              color: Colors.grey.shade50,
              padding: const EdgeInsets.all(10.0),
              child: ListView.builder(
                reverse: true, // Show most recent events at the top
                itemCount: _eventHistory.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4.0),
                    child: Text(
                      _eventHistory[index],
                      style: TextStyle(
                        fontSize: 13,
                        color: _eventHistory[index].startsWith("❌") ||
                                _eventHistory[index].contains("BLOCKED")
                            ? Colors.red
                            : Colors.black87,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (_) => _handleSend(),
                    decoration: const InputDecoration(
                        labelText: 'Enter secure message...'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _handleSend,
                  tooltip: 'Layer 1: Send Message',
                ),
                IconButton(
                  icon: const Icon(Icons.download),
                  onPressed: () {
                    // Simulating receiving an encrypted attachment.
                    // The payload is what Layer 1 (decryption) and
                    // Layer 2 (CNG) will process.
                    const simulatedEncryptedAttachmentString =
                        "EncryptedPayload: 0xDEADBEEF...";
                    final encryptedBytes = Uint8List.fromList(
                        utf8.encode(simulatedEncryptedAttachmentString));

                    _handleReceiveAttachment(encryptedBytes);
                  },
                  tooltip: 'Layers 1 & 2: Receive & Check Attachment',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
